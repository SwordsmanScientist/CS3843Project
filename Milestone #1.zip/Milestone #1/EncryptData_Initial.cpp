// EncryptData.cpp
//
// This file uses the input data and key information to encrypt the input data
//

#include "Main.h"

//////////////////////////////////////////////////////////////////////////////////////////////////
// code to encrypt the data as specified by the project assignment
int encryptData(char *data, int dataLength)
{
	int resulti = 0;

	gdebug1 = 0;					// a couple of global variables that could be used for debugging
	gdebug2 = 0;					// also can have a breakpoint in C code

	__asm {

		mov ecx, 0					
		mov edi, data				

		xor ebx, ebx; 
		mov bh, gPasswordHash[0]
		mov bl, gPasswordHash[1]

		LOOP1:				
			mov al, byte ptr[edi + ecx]				// Store the byte that will be manipulated

			xor al, gkey[ebx]					// XOR the current byte with keyfile[ebx]
			mov byte ptr[edi + ecx], al			// Write the changed byte to the file

			inc ecx								// Go to the next byte
			cmp dataLength, ecx					// Check if the EOF has been reached
			jne LOOP1							// Loop again

			jmp done							// End program

		done:

	}

	return resulti;
} // encryptData