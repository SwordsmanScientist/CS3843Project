// EncryptData.cpp
//
// This file uses the input data and key information to encrypt the input data
//

#include "Main.h"

//////////////////////////////////////////////////////////////////////////////////////////////////
// code to encrypt the data as specified by the project assignment
int encryptData(char *data, int dataLength)
{
	int resulti = 0;

	gdebug1 = 0;					// a couple of global variables that could be used for debugging
	gdebug2 = 0;					// also can have a breakpoint in C code

	__asm {
		
		//Move data to edi
		mov edi, data				

		//Clear registers
		xor ecx, ecx
		xor edx, edx
		xor eax, eax
		xor ebx, ebx 

		//Store passwordhash in ebx
		mov bh, gPasswordHash[0]
		mov bl, gPasswordHash[1]

		//Loop through file
		LOOP1:				
			mov al, byte ptr[edi + ecx]				// Store the byte that will be manipulated
			push ecx
			//BEGIN ENCRYPT
				// XOR the current byte with keyfile[ebx]
				xor al, gkey[ebx]		
				//A: rotates left 3 times
				rol al, 3	
				//B: swaps nibbles
				rol al, 4							
				//C: reverse bit order
				mov cl, 7
				LOOP2:
					shr al, 1
					jnc SKIP
					mov ah, 1
					shl ah, cl
					add dl, ah
					xor ah, ah

					SKIP:
					dec cl
					cmp cl, 0
					jne LOOP2
				mov al, dl
				xor edx, edx
				//D: swap even/odd bits
				//E: Swap with encode table
			//END ENCRYPT
			pop ecx

			mov byte ptr[edi + ecx], al			// Write the changed byte to the file

			inc ecx								// Go to the next byte
			cmp dataLength, ecx					// Check if the EOF has been reached
			jne LOOP1							// Loop again

			jmp done							// End program

		done:

	}

	return resulti;
} // encryptData